# 📦 Persistent Update Folder

If you are using the suitefish windows client to deploy and update this product, this folder will not be overwritten during updates.

🐟 Bugfish